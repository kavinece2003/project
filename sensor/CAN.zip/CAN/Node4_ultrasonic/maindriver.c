#include <lpc21xx.h>
#include "lcd.c"
#include"delay.h"
#include "defines.h"
#include"can.c"
#include "ultrasonic.c"

int main(void)
{	CAN_MSG m1;
	int range;
	PINSEL1|=1<<22;

	lcd_init();
	can_init();
	ultrasonic_init();

	m1.id=0x03;
	m1.dlc=4;
	m1.rtr=0;

	while(1)
	{
		lcd_command(0xc0);	
		lcd_str("Water lvl:");

		 range=get_range();
		 //distance=(range*343)/2;

		 lcd_data((range/100)+48);	  //hundreds place
		 lcd_data(((range/10)%10)+48); //tens place
		 lcd_data((range%10)+48);	  //ones place
		 lcd_str("cm");
	m1.AByte=range;

	delay_ms(700);

	can_tx(m1);

	//delay_ms(500);
	}
}
