#ifndef _delay_
#define _delay_

void delay_ms(int s)
{
	T0PR=60000-1;
	T0TCR=0X01;
	while(T0TC<s);
	T0TCR=0x03;
	T0TCR=0x00;
}


void delay_us(int us)
{
	T0PR=60-1;
	T0TCR=0X01;
	while(T0TC<us);
	T0TCR=0X03;
	T0TCR=0X00;
}

#endif

