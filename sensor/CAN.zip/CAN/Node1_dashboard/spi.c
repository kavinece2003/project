#include "defines.h"

void spi_init()
{
	PINSEL0|=0x1500;//p0.4,p0.5 and p0.6
	S0SPCCR=spi_speed;
	S0SPCR=(1<<mstr_bit)|mode_0;
	IODIR0|=cs;
}

u8 spi_write(u8 data)
{
  u8 stat=S0SPSR; //clear SPIF flag
  S0SPDR=data;
  while(((S0SPSR>>spif_flag)&1)==0);
  return S0SPDR;
}

f32 mcp3204_read(u8 channelNo)
{
  u8 hByte,lByte;
  u32 adcVal=0;
   
  //select/activate chip 
  CLRBIT(IOPIN0,CS);

	//delay_ms(100);

  spi_write(0x06);
  hByte = spi_write(channelNo<<6);
  lByte = spi_write(0x00);	

	//de-select/de-activate chp
  SETBIT(IOSET0,CS);
	//delay_ms(100);
  adcVal=((hByte&0x0f)<<8)|lByte;
  return ((adcVal*3.3)/4096);
}
	

