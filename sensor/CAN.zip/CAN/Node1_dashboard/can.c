//CAN tx
#include<lpc21xx.h>
#include "defines.h"

typedef struct can_msg
{
	unsigned int id;
	unsigned char dlc;
	unsigned char rtr;
	float AByte;
}CAN_MSG;


void can_init()
{
	PINSEL1|=0x14000;  //p0.22 and p0.23 as Rd and Td
	VPBDIV=1;          // PClk as 60Mhz
	C2MOD= 1;			   //reset mode
	//configurations done in reset mode
	AFMR=0x02; //acceptance filter for receiving all type of messages
	C2BTR=0x001C001D;  //BRP=(PClk/Bit rate *16)
	//return to normal mode for can activities
	C2MOD=0;     //normal mode
}

void can_tx(CAN_MSG m1)
{
	C2TID1=m1.id;		//assign msg id to transmit buffer 1
	C2TFI1=(m1.dlc<<16);   //16-19 bit of TFI1 is dlc
	if(m1.rtr==0)		   //data frame
	{
		C2TFI1&=~(1<<30);		  //rtr 0
		C2TDA1=m1.AByte;		  //4 byte data
	}
	else{						   //rtr 1
	C2TFI1|=(1<<30);
	}
	C2CMR=(1<<0)|(1<<5);		   // Start Xmission and tranmit buffer 1
	while((C2GSR&(1<<3))==0);	   // wait until the xmission is over
}

void can_rx(CAN_MSG * m1)
{
	while((C2GSR&1)==0); // checking status of receive buffer status
	m1->id=C2RID;
	m1->dlc=(C2RFS>>16)&0xf; //getting 16-19 bit values alone
	m1->rtr=(C2RFS>>30)&1;	  // getting rtr value

	if(m1->rtr==0)	   //if data frame
	{
		m1->AByte=C2RDA;
	}
	C2CMR=1<<2;  //free the rceive buffer

}
