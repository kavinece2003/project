#include "defines.h"
#define eint0_fun 0X1
#define irq_slot 1<<5



void eint0_isr(void) __irq
{
	EXTINT=0X01;
	emp_in=emp_in+1;
	VICVectAddr=0;
}

void int_config()
{	
	PINSEL1|=eint0_fun;

	VICIntSelect=0;
	VICVectCntl0=irq_slot|14;
	VICVectAddr0=(unsigned long)eint0_isr;
	
	EXTMODE=0X01;
	EXTPOLAR=0X00;
	
	VICIntEnable=1<<14;

}

