#include<lpc21xx.h>

#include "delay.h"
#include "defines.h"
#include "lcd.h"
#include "spi.c"
#include "can.c"

#define led 1<<17
void display(int temp)
{
		lcd_command(0x80);
		lcd_str("Temp:");
		lcd_float(temp);
		lcd_str(" C");
}

int main()
{	
	float temp;
	CAN_MSG m1;
	lcd_init();
	spi_init();
	can_init();
	m1.id=0x01;
	m1.dlc=4;
	m1.rtr=0;
	IODIR0=led;

	while(1)
	{
		temp = mcp3204_read(0);
		//temp = f1 * 10;
		if(temp>45)
		{
			IOCLR0=led;
		}
		else if(temp<=45)
		{
			IOSET0=led;
		}
		
		//humid = ((current_voltage - Vdry) / (Vwet - Vdry)) * 100;
		display(temp);
		delay_ms(500);
		m1.AByte=temp;
		//delay_ms(1000);
		can_tx(m1);
		//delay_ms(300);
	}

}